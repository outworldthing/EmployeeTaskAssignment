﻿using EmployeeTaskAssignmentAPI.Data;
using EmployeeTaskAssignmentAPI.Migrations;
using EmployeeTaskAssignmentAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTaskAssignmentAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private readonly DataContext _dbContext;

        public ProjectController(DataContext context)
        {
            _dbContext = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<Project>>> getProjects()
        {
            var projectsDb = await _dbContext.Project
                .Include(c => c.employees)
                .ToListAsync();

            var employeeDb = await _dbContext.Employee.ToListAsync();

            foreach (var project in projectsDb)
            {
                if(project.employees.Count == 0)
                {
                    project.EstimateTime = 0;
                    break;
                }

                foreach (var employee in project.employees)
                {
                    project.EstimateTime += employee.EstimateTime;
                };
            };

            await _dbContext.SaveChangesAsync();

            return projectsDb;
        }

        [HttpPut]
        public async Task<ActionResult<List<Project>>> addEmployeeToProject()
        {
            Random rnd = new Random();
            int employeeId = rnd.Next(1, 5);  
            int projectId = rnd.Next(1, 3);

            var projectsDb = await _dbContext.Project
                .Include(e => e.employees)
                .FirstOrDefaultAsync();
            if (projectsDb == null)
                return BadRequest("Project not found");

            var employeeDb = await _dbContext.Employee.FindAsync(employeeId);
            if (employeeDb == null)
                return BadRequest("Employee not found");

            foreach(var employee in projectsDb.employees)
            {
                if(employeeDb == employee)
                {
                    return BadRequest("Employee is already added to the task");
                }
            }

            projectsDb.employees.Add(employeeDb);

            await _dbContext.SaveChangesAsync();
           
            return Ok(await _dbContext.Project.Include(c => c.employees).ToListAsync());
        }

        [HttpDelete]
        public async Task<ActionResult<List<Project>>> removeEmployeeFromProject(int employeeId)
        {
            var projectsDb = await _dbContext.Project
                .Include(e => e.employees)
                .FirstOrDefaultAsync();

            if (projectsDb == null)
                return BadRequest("Project not found");

            var employeesDb = await _dbContext.Employee.FindAsync(employeeId);
            if (employeesDb == null)
                return BadRequest("Employee not found");

            projectsDb.employees.Remove(employeesDb);

            await _dbContext.SaveChangesAsync();

            return Ok(await _dbContext.Project.Include(c => c.employees).ToListAsync());
        }
    }
}
