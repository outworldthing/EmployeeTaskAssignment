﻿using EmployeeTaskAssignmentAPI.Data;
using EmployeeTaskAssignmentAPI.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTaskAssignmentAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly DataContext _dbContext;
        
        public EmployeeController(DataContext context)
        {
            _dbContext = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<Employee>>> getEmployees()
        {
            return Ok(await _dbContext.Employee.ToListAsync());
        }
    }
}
