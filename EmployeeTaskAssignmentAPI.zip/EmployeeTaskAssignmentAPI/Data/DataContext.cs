﻿using EmployeeTaskAssignmentAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeTaskAssignmentAPI.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options) { }
        public DbSet<Employee> Employee => Set<Employee>();
        public DbSet<Project> Project => Set<Project>();
    }
}
