﻿namespace EmployeeTaskAssignmentAPI.Models
{
    public class EmployeeProject
    {
        public int EmployeeId { get; set; }
        public int ProjectId { get; set; }
    }
}
