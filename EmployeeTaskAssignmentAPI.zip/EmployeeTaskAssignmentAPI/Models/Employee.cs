﻿using System.Text.Json.Serialization;

namespace EmployeeTaskAssignmentAPI.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; } = string.Empty;
        public int EstimateTime { get; set; }
        public int ActualTime { get; set; }

        [JsonIgnore]
        public List<Project> projects { get; set; } = new();
    }
}
